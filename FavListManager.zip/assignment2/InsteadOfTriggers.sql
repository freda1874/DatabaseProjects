--  create a trigger when insert new entry in FAVLIST_VIEW, you only need to insert showid, userid,the FAVOURITEID should generate automatically
-- This FAVLIST_Trigger manages the favlist which allows users to add or remove favlist:
-- 1. When adding a new show to the view that isn't already in the list:
--    - Insert a new entry in FAVOURITELISTTABLE with auto-incremented FAVOURITEID and STILLFAV set to 'y'.
--    - Add a corresponding entry in FAVOURITEHISTORY, referencing FAVOURITEID, setting adddate to sysdate, and leaving removedate null.
-- 2. When removing a show from FAVLIST_VIEW:
--    - Update STILLFAV to 'n' in FAVOURITELISTTABLE.
--    - Set the removedate to sysdate in FAVOURITEHISTORY.
CREATE
OR REPLACE TRIGGER FAVLIST_Trigger INSTEAD OF
INSERT
    or delete ON FAVLIST_VIEW FOR EACH ROW
DECLARE newFAVOURITEID NUMBER;

BEGIN if inserting then
INSERT INTO
    FAVOURITELISTTABLE (FAVOURITEID, showid, userid, STILLFAV)
VALUES
    (
        seq_FAVOURITEID.nextval,
        :new.showid,
        :new.userid,
        'y'
    )
RETURNING
    FAVOURITEID INTO newFAVOURITEID;

INSERT INTO
    FAVOURITEHISTORY (FAVOURITEID, ADDDATE, REMOVEDATE)
VALUES
    (newFAVOURITEID, sysdate, null)
RETURNING
    FAVOURITEID INTO newFAVOURITEID;

end if;

if deleting then
UPDATE FAVOURITELISTTABLE
SET
    STILLFAV = 'n'
WHERE
    FAVOURITEID = :old.FAVOURITEID;

UPDATE FAVOURITEHISTORY
SET
    REMOVEDATE = sysdate
WHERE
    FAVOURITEID = :old.FAVOURITEID;

end if;

END;

-- SHOWS_VIEW Trigger Operations:
-- 1. Insert: Add a movie genre to SHOWGENRE. Automatically generate IDSHOWGENRE and retrieve GENREID from GENRE table.
-- 2. Update: Modify the existing genre in SHOWGENRE based on new GENREID.
-- 3. Delete: Remove the corresponding entry from SHOWGENRE based on matching showid and genreid.
CREATE
OR REPLACE TRIGGER shows_trigger INSTEAD OF
INSERT
    OR
UPDATE
OR DELETE ON shows_view FOR EACH ROW
BEGIN IF inserting THEN
INSERT INTO
    showgenre (idshowgenre, genreid, showid)
VALUES
    (
        seq_showgenre.NEXTVAL,
        (
            SELECT
                genreid
            FROM
                genre
            WHERE
                genre = :new.genre
        ),
        :new.showid
    );

END IF;

IF updating THEN
UPDATE showgenre
SET
    genreid = (
        SELECT
            genreid
        FROM
            genre
        WHERE
            genre = :new.genre
    )
WHERE
    showid = :old.showid
    AND genreid = (
        SELECT
            genreid
        FROM
            genre
        WHERE
            genre = :old.genre
    );

END IF;

IF deleting THEN
DELETE FROM showgenre
WHERE
    showid = :new.showid
    AND genreid = (
        SELECT
            genreid
        FROM
            genre
        WHERE
            genre = :old.genre
    );

END IF;

END;

-- USERNAME_Trigger Trigger Actions: INSERT, UPDATE
-- On UPDATE: 
-- 1. Add new name to 'names' table and retrieve new 'idname' (if name doesn't exist).
-- 2. Add new entry to 'USERNAME' table with new names, setting 'startdate' to sysdate and 'enddate' to null.
-- 3. Update original 'USERNAME' entry, setting 'enddate' to sysdate.
-- On INSERT:
-- 1. Add name to 'names' table and get 'idname' (if name doesn't exist).
-- 2. Insert into 'USERNAME' table with new details, 'startdate' set to sysdate, and 'enddate' to null.
-- NOTE: Username deletion is not allowed; users must always have a name.
CREATE OR REPLACE TRIGGER username_trigger INSTEAD OF
    INSERT OR UPDATE ON username_view
    FOR EACH ROW
DECLARE
    newidname  NUMBER;
    name_count NUMBER;
BEGIN
    IF inserting THEN 
        -- First, count if the name combination exists
        SELECT
            COUNT(DISTINCT idname)
        INTO name_count
        FROM
            names
        WHERE
                firstname = :new.firstname
            AND lastname = :new.lastname;

        IF name_count = 0 THEN
            INSERT INTO names (
                idname,
                firstname,
                lastname
            ) VALUES (
                seq_names.NEXTVAL,
                :new.firstname,
                :new.lastname
            ) RETURNING idname INTO newidname;

        ELSE
            SELECT
                idname
            INTO newidname
            FROM
                names
            WHERE
                    firstname = :new.firstname
                AND lastname = :new.lastname;

        END IF;

        INSERT INTO username (
            idusername,
            userid,
            idname,
           
            startdate,
            enddate
        ) VALUES (
            seq_username.NEXTVAL,
            :new.userid,
            newidname,
            
            sysdate,
            NULL
        );

    END IF;

    IF updating THEN
        SELECT
            COUNT(DISTINCT idname)
        INTO name_count
        FROM
            names
        WHERE
                firstname = :new.firstname
            AND lastname = :new.lastname;

        IF name_count = 0 THEN
            INSERT INTO names (
                idname,
                firstname,
                lastname
            ) VALUES (
                seq_names.NEXTVAL,
                :new.firstname,
                :new.lastname
            ) RETURNING idname INTO newidname;

        ELSE
            SELECT
                idname
            INTO newidname
            FROM
                names
            WHERE
                    firstname = :new.firstname
                AND lastname = :new.lastname;

        END IF;
 
      
            UPDATE username
            SET 
                startdate = sysdate,
                enddate=null 
                  WHERE
                userid = :old.userid;
        END IF;
 

END;