-- create sub tables: shows and genres related


CREATE TABLE showstable (
    showid              VARCHAR2(26 BYTE) NOT NULL PRIMARY KEY,
    title               VARCHAR2(128 BYTE) NOT NULL,
    showtype            VARCHAR2(26 BYTE),
    description         VARCHAR2(4000 BYTE),
    releaseyear         NUMBER(38, 0),
    agecertification    VARCHAR2(26 BYTE),
    runtime             NUMBER(38, 0),
    productioncountries VARCHAR2(26 BYTE)
)；



CREATE TABLE genre (
    "GENREID" VARCHAR2(26 BYTE) NOT NULL PRIMARY KEY,
    "GENRE"   VARCHAR2(26 BYTE)
        NOT NULL ENABLE
)；


CREATE TABLE showgenre (
    idshowgenre NUMBER NOT NULL PRIMARY KEY,
    genreid     VARCHAR2(50) NOT NULL,
    showid      VARCHAR2(50) NOT NULL,
    FOREIGN KEY ( genreid )
        REFERENCES genre ( genreid ),
    FOREIGN KEY ( showid )
        REFERENCES showstable (showid)
)

-- insert into tables

CREATE SEQUENCE seq_showgenre START WITH 1 INCREMENT BY 1 NOMAXVALUE;

INSERT INTO showstable (
    showid,
    title,
    showtype,
    description,
    releaseyear,
    agecertification,
    runtime,
    productioncountries
)
    SELECT DISTINCT
        showid,
        title,
        showtype,
        description,
        releaseyear,
        agecertification,
        runtime,
        productioncountries
    FROM
        showsnew;

INSERT INTO genre (
    genreid,
    genre
)
    SELECT DISTINCT
        genreid,
        genre
    FROM
        showsnew;

INSERT INTO showstable (
    showid,
    title,
    showtype,
    description,
    releaseyear,
    agecertification,
    runtime,
    productioncountries
)
    SELECT DISTINCT
        showid,
        title,
        showtype,
        description,
        releaseyear,
        agecertification,
        runtime,
        productioncountries
    FROM
        showsnew;

    INSERT INTO showgenre (
        idshowgenre,
        genreid,
        showid
    )
        SELECT
            seq_showgenre.NEXTVAL,
            s.genreid,
            s.showid
        FROM
            (
                SELECT DISTINCT
                    sn.genreid,
                    sn.showid
                FROM
                    showsnew sn
            ) s

-- create sub tables: user and names related

CREATE TABLE usertable (
    userid   NUMBER NOT NULL PRIMARY KEY,
    email    VARCHAR2(26 BYTE),
    password VARCHAR2(26 BYTE)
);

CREATE TABLE names (
    idname    NUMBER NOT NULL PRIMARY KEY,
    firstname VARCHAR2(50) NOT NULL,
    lastname  VARCHAR2(50) NOT NULL
);

CREATE TABLE username (
    idusername NUMBER NOT NULL PRIMARY KEY,
    userid     NUMBER NOT NULL,
    idname     NUMBER NOT NULL,
    startdate  TIMESTAMP(6) NOT NULL,
    enddate    TIMESTAMP(6) DEFAULT NULL,
    FOREIGN KEY ( userid )
        REFERENCES usertable ( userid ),
    FOREIGN KEY ( idname )
        REFERENCES names ( idname )
);


CREATE SEQUENCE seq_username START WITH 1 INCREMENT BY 1 NOMAXVALUE;

 -- insert entries in usertable from users
INSERT INTO usertable (
    userid,
    email,
    password
)
    SELECT DISTINCT
        userid,
        email,
        password
    FROM
        users;

            -- sequence for names table
CREATE SEQUENCE seq_names START WITH 1 INCREMENT BY 1 NOMAXVALUE;

            -- insert entries in names from users
INSERT INTO names (
    idname,
    firstname,
    lastname
)
    SELECT
        seq_names.NEXTVAL,
        firstname,
        lastname
    FROM
        (
            SELECT DISTINCT
                firstname,
                lastname
            FROM
                users
        );

INSERT INTO username (
    idusername,
    userid,
    idname,
    startdate,
    enddate
)
    SELECT
        seq_username.NEXTVAL,
        userid,
        idname,
        startdate,
        enddate
    FROM
        (
            SELECT DISTINCT
                userid,
                idname,
                '2023-08-04' AS startdate,
                NULL         AS enddate
            FROM
                     users
                INNER JOIN names ON users.firstname = names.firstname
                                    AND users.lastname = names.lastname
        );


-- create sub table for favlist related tables
CREATE SEQUENCE SEQ_FAVOURITEID START WITH 53 INCREMENT BY 1 NOMAXVALUE;


            
CREATE TABLE favouritelisttable (
    favouriteid NUMBER(38, 0) NOT NULL PRIMARY KEY,
    showid      VARCHAR2(26 BYTE) NOT NULL,
    userid      NUMBER(38, 0) NOT NULL,
    stillfav    CHAR(1 BYTE) NOT NULL
);
                -- create sub table FAVOURITEHISTORY
CREATE TABLE favouritehistory (
    favouriteid NUMBER(38, 0) NOT NULL PRIMARY KEY,
    adddate     TIMESTAMP(6) NOT NULL,
    removedate  TIMESTAMP(6) DEFAULT NULL
)
                -- insert entries in FAVOURITELIS TTABLE 
INSERT INTO favouritelisttable (
    favouriteid,
    showid,
    userid,
    stillfav
)
    SELECT DISTINCT
        favouriteid,
        showid,
        userid,
        stillinfavourites
    FROM
        favouritelist;

                -- insert entries in favouritehistory from FAVOURITELIST
INSERT INTO favouritehistory (
    favouriteid,
    adddate,
    removedate
)
    SELECT DISTINCT
        favouriteid,
        adddate,
        removedate
    FROM
        favouritelist;

-- now we have all the table and data ready, we can start to make views to replace original multivalued tables
-- view of show and genre
CREATE VIEW shows_view AS
    SELECT distinct
        st.showid,
        st.title,
        st.showtype,
        st.description,
        st.releaseyear,
        agecertification,
        runtime,
        productioncountries,
        g.genre
    FROM
        showstable st
        LEFT JOIN showgenre  sg ON st.showid = sg.showid
        LEFT JOIN genre      g ON sg.genreid = g.genreid;

CREATE VIEW username_view AS
    SELECT
    distinct
        ut.userid,
        email,
        password,
        n.firstname,
        n.lastname
    FROM
        usertable ut
        LEFT JOIN username  un ON ut.userid = un.userid
        LEFT JOIN names     n ON un.idname = n.idname
    WHERE
        enddate IS NULL;

                -- view of favlist that only shows the effective user's favlist
CREATE VIEW favlist_view AS
    SELECT
        ft.favouriteid,
        ft.showid,
        ft.userid
    FROM
        favouritelisttable ft
        LEFT JOIN favouritehistory   fh ON ft.favouriteid = fh.favouriteid
    WHERE
        fh.removedate IS NULL;